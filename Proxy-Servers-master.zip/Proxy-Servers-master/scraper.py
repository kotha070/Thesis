from pymongo import MongoClient
from concurrent.futures import ThreadPoolExecutor, as_completed
from bs4 import BeautifulSoup
from ipwhois import IPWhois
from ipwhois.exceptions import BaseIpwhoisException
import requests 
import json
import time
import ipaddress


header = { 
  'User-Agent' : 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/\ 97.0.4692.71 Safari/537.36',
  'From'       : 'charliekincs@gmail.com' 
  }


def fetch_data(url: str) -> dict:
  ''' get the HTML data table or JSON data at a URL '''
  try:
    content = BeautifulSoup(requests.request('GET', url, timeout=4, headers=header).text, 'html.parser')
  except BaseException as ex:
    print(f'{type(ex).__name__} when fetching data from {url}') # document network-based exceptions but continue running
    return {}

  match url:
    case ('https://free-proxy-list.net/' 
        | 'https://hidemy.name/en/proxy-list/'
        | 'http://free-proxy.cz/en/'
        | 'https://advanced.name/freeproxy'
        | 'https://vpnoverview.com/privacy/anonymous-browsing/free-proxy-servers/'
        | 'https://sslproxies.org/'
        | 'https://www.iplocation.net/proxy-list'):
      return {'html' : content.find('tbody')}
    case 'https://spys.one/en/':
      return {'html' : content.find('table', {'width' : '65%'})}
    case 'https://proxylist.geonode.com/api/proxy-list?limit=50&page=1&sort_by=lastChecked&sort_type=desc':
      return {'json' : json.loads(str(content))['data']}
    case 'https://www.echolink.org/proxylist.jsp':
      return {'html' : content.find('table', {'bordercolorlight' : '#CCCCCC'})}
      

def validate_ip(ip: str) -> bool:
  try:
    ipaddress.ip_address(ip)
  except:
    return False
  return True
  

def get_ip_location(ip: str) -> list:
  ''' Get the location of an IP address '''
  if not validate_ip(ip):
    return []

  try:
    location = requests.request('GET', f'https://geolocation-db.com/json/8dd79c70-0801-11ec-a29f-e381a788c2c0/{ip}', timeout=3, headers=header).text
  except BaseException as ex:
    print(f'{type(ex).__name__} when getting location of {ip}')
    return []

  if (location := json.loads(location)) and location['latitude'] != 'Not found' and location['longitude'] != 'Not found':
    return location
  return []


def print_html(proxy_table: BeautifulSoup) -> None:
  for row in proxy_table.find_all('tr'):
    for data in row.find_all('td'):
      print(data.text + '\t', end='')
    print()


def whois(ip: str) -> dict:
  ''' Wrapper for IPWhois.lookup_whois() with exception handling '''
  try:
    return IPWhois(ip).lookup_whois()
  except BaseIpwhoisException as ex:
    print(f'{type(ex).__name__} when getting whois data from {ip}')
    return {}
  
  
def html_to_documents(proxy_table: BeautifulSoup) -> list:
  ''' Generate a document for each row in the HTML table object. Return a list of the documents '''
  if proxy_table is None: 
    return []

  def generate_document(row: BeautifulSoup) -> dict:
    for data in row.find_all('td'):
      data = data.text.split(':')[0].lstrip('0#_ ') # get rid of port number and extra leading characters
      if (location_data := get_ip_location(data)) and (whois_data := whois(data)):
        return whois_data | location_data # merge the two dictionaries

  documents = []
  with ThreadPoolExecutor(max_workers=30) as executor:
    future_to_row = {executor.submit(generate_document, row) : row for row in proxy_table.find_all('tr')}
    for future in as_completed(future_to_row):
      if result := future.result():
        documents.append(result)
  
  return documents


def json_to_documents(json_data: list) -> list:
  if json_data is None:
    return []  

  with ThreadPoolExecutor(max_workers=30) as executor:
    future_to_index = {}
    for i, point in enumerate(json_data):
      if validate_ip(point.get('ip')):
        future_to_index[executor.submit(whois, point['ip'])] = i
        future_to_index[executor.submit(get_ip_location, point['ip'])] = i

    for future in as_completed(future_to_index):
      if result := future.result():
        json_data[future_to_index[future]] |= result   

  return json_data
  

def main() -> None:
  start_time = time.time()
  urls = [
          'https://proxylist.geonode.com/api/proxy-list?limit=50&page=1&sort_by=lastChecked&sort_type=desc',
          'https://www.echolink.org/proxylist.jsp',
          'https://www.iplocation.net/proxy-list',
          'https://sslproxies.org/',
          'https://vpnoverview.com/privacy/anonymous-browsing/free-proxy-servers/',
          'https://advanced.name/freeproxy',
          'http://free-proxy.cz/en/',
          'https://hidemy.name/en/proxy-list/',
          'https://free-proxy-list.net/'
         ]

  proxy_server_collection = MongoClient().proxy_server_db.proxy_server_collection
  for url in urls:
    if (proxy_data := fetch_data(url)) is None:
      continue
    documents = html_to_documents(proxy_data['html']) if 'html' in proxy_data else json_to_documents(proxy_data['json'])
    for document in documents:
      proxy_server_collection.replace_one({'query' : document['query']} if 'query' in document else document, document, upsert=True)

  print(f'--- {(time.time() - start_time)} seconds ---')
  
  with open('test.txt', 'a') as test_file:
    test_file.write(str(time.time()))


if __name__ == '__main__':
  main()