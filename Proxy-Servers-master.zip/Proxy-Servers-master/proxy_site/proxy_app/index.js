

// Initialize and add the map
function initMap() {
  // The location of Uluru
  const uluru = { lat: -25.344, lng: 131.031 };
  // The map, centered at Uluru
  const map = new google.maps.Map(document.getElementById("map"), {
    zoom: 4,
    center: uluru,
  });
  // The marker, positioned at Uluru
  const marker = new google.maps.Marker({
    position: uluru,
    map: map,
  });
}
window.initMap = initMap;

const submit_button = document.getElementById('submit');
submit_button.addEventListener('click', async _ => {
  try {     
    const response = await fetch('yourUrl', {
      method: 'get',
      body: {
        // Your body
      }
    });
    console.log('Completed!', response);
  } catch(err) {
    console.error(`Error: ${err}`);
  }
});

async function get_proxy_data() {
  // import('mongodb').then(module => { MongoClient = module });
  var { MongoClient } = require("mongodb").MongoClient;
  client = new MongoClient("mongodb://localhost:27017/proxy_server_db");
  await client.connect();
  return await client.db("proxy_server_db").collection("proxy_server_collection").find({}).toArray();
}
