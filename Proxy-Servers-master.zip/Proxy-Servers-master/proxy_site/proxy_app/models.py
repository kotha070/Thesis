from django.db import models
from mongoengine import Document, fields

# Create your models here.

class ProxyServer(Document):
    ip = fields.StringField(max_length=39)

