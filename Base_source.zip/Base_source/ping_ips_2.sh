#!/bin/bash

input_file="ips.txt"
output_file="rtt_stats.csv"

# Remove the output file if it already exists
rm -f "$output_file"

# Write the CSV header
echo "IP Address,Min,Avg,Max,Mdev" > "$output_file"

# Loop through each IP address in the input file
while IFS= read -r ip_address; do
    # Ping the IP address and extract the RTT stats if available
    rtt_stats=$(ping -c 3 "$ip_address" | grep "rtt" | awk '{print $4, $5, $6, $7, $8}')

    # Check if RTT stats are available
    if [[ -n "$rtt_stats" ]]; then
        # Write the IP address and RTT stats to the output file in CSV format
        echo "$ip_address,$rtt_stats" >> "$output_file"
    fi
done < "$input_file"

